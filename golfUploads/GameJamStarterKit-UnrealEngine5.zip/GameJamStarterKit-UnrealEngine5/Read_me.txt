SideFX Game Jam Toolkit V1.1

--Install--
To install and see the tools in Houdini.
-Go to documents -> Houdini19.5 (or newer version) -> otls
-Drag the hda files in the otls folder

To install Houdini engine
https://vimeo.com/442124526

--Resources--
These files are us with the tools
-PSD tool = this inculde an example psd and models to use in the tool
-Trim tool = these are layouts for auto trim creation
-WFC tool = this has the base models and texture to input in the tool
-Leave texture = this is for the tree tool, when making leave cards


--More info and videos--
https://www.sidefx.com/tutorials/ue4-starter-kit/